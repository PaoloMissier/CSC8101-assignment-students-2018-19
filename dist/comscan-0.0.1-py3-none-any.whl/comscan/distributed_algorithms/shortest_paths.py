
from pyspark import SparkContext
from comscan.model.graph import Graph
from comscan.algorithms.shortest_path import single_source_shortest_paths_dijkstra
from comscan.algorithms.shortest_path import single_source_shortest_paths_dijkstra

def compute_shortest_paths(sc: SparkContext, graph: Graph):

    graphBC = sc.broadcast(graph)

    def _single_source_shortest_paths(source: int):
        """
        Single-Source Shortest path function for the Spark workers.
        Prerrequisite: the 'algorithms' module needs to be added as dependency to all workers with sc.addPyFile
        :param source: source node
        :return:
        """

        paths, distances = single_source_shortest_paths_dijkstra(graphBC.value, source=source)
        return source, paths

    nodes_rdd = sc.parallelize(graph.nodes)

    shortest_paths_rdd = nodes_rdd.map(_single_source_shortest_paths)

    return shortest_paths_rdd
