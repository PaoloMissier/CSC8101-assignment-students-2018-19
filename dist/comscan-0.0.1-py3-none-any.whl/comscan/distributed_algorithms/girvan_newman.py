from comscan.distributed_algorithms.betweenness import get_edge_with_highest_betweenness
from comscan.algorithms.connected import connected_components
from comscan.algorithms.connected import number_connected_components
from comscan.model.graph import Graph
from pyspark import SparkContext


def girvan_newman(sc: SparkContext, graph: Graph, level: int):
    """returns communities at certain level"""
    comp = girvan_newman_generator(sc, graph)

    for c in comp:
        if len(c) == level:
            return c


def girvan_newman_generator(sc: SparkContext, graph: Graph):
    """Generator of dendogram"""

    if graph.number_of_edges() == 0:
        yield tuple(connected_components(graph))
        return

    _graph = graph.copy()
    _remove_self_loops(_graph)

    while _graph.number_of_edges() > 0:
        yield _without_highest_betweenness_edge(sc, _graph)


def _without_highest_betweenness_edge(sc: SparkContext, graph):
    original_num_components = number_connected_components(graph)
    num_connected_components = original_num_components

    while num_connected_components <= original_num_components:
        # edges = get_edges_with_highest_betweenness(graph)
        #
        # for edge in edges:
        #     graph.remove_edge(*edge)

        edge = get_edge_with_highest_betweenness(sc, graph)
        graph.remove_edge(*edge)

        new_components = tuple(connected_components(graph))
        num_connected_components = len(new_components)

    return new_components


def _remove_self_loops(graph):
    for n, neighbors in graph.adj_list.items():
        if n in neighbors:
            graph.remove_edge(n, n)
