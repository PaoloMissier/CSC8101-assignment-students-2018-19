import sys

import matplotlib.pyplot as plt
from networkx import nx
from comscan.model.graph import Graph


def draw(graph):
    """Draw the graph showing edge weight

    """

    graph_nx = nx.Graph()
    graph_nx.add_weighted_edges_from(graph.weighted_edges)

    labels = nx.get_edge_attributes(graph_nx, 'weight')
    pos = nx.spring_layout(graph_nx)
    nx.draw_networkx(
        graph_nx, pos=pos,
        with_labels=False,
        node_size=100,
        node_color="skyblue", node_shape="o"
    )

    plt.axis('off')
    plt.title(graph.name)
    plt.show()


def draw_small_graph(graph):
    """Draw the graph showing edge weight

    """

    graph_nx = nx.Graph()
    graph_nx.add_weighted_edges_from(graph.weighted_edges)

    labels = nx.get_edge_attributes(graph_nx, 'weight')
    pos = nx.spring_layout(graph_nx)
    nx.draw_networkx_edge_labels(
        graph_nx, pos=pos,
        edge_labels=labels
    )

    nx.draw(graph_nx, pos=pos,
            with_labels=True, node_size=10,
            node_color="skyblue", node_shape="o",
            alpha=0.5, linewidths=30)

    plt.title(graph.name)
    plt.show()


def main():
    """Draw a sample graph"""
    nodes = [1, 2, 3, 4, 5]
    edges = [(1, 2), (1, 3), (1, 5)]
    graph = Graph('Visualizer Sample')
    graph.add_nodes(nodes)
    graph.add_edges(edges)
    draw(graph)


if __name__ == '__main__':
    main()
