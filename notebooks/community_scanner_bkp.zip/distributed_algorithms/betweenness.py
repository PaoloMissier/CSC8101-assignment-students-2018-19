"""This module provides means to compute edge betweenness centrality of a graph
using Apache Spark Resilient Distributed Datasets"""

from pyspark import RDD

__author__ = "Eduardo Hernandez"
__email__ = "https://www.linkedin.com/in/eduardohernandezj"

def compute_edge_betweenness(shortest_paths_rdd: RDD) -> RDD:
    """Compute edge betweenness centrality of a graph in a distributed fashion given the shortest paths

    :param shortest_paths_rdd:
    shortest_paths_rdd -> [(source, paths_dict)]
    paths_dict -> {target: [shortest_path]}
    shortest_path -> [node]

    :returns RDD with edge betweenness:
    [(edge, betweenness)]
    edge -> (u,v)
    betweenness -> float
    """

    # paths_count_rdd -> [((source, target), paths_count)]
    paths_count_rdd = shortest_paths_rdd.flatMap(_map_paths_count)

    # edges_count_rdd -> [((source, target), (edge, edge_count))]
    # (source, target): define the nodes for shortest path computation, i.e. this is not an edge
    # edge -> (u, v)
    # edge_count -> number of shortest paths between 'source' and 'target' that goes through 'edge'
    edges_count_rdd = shortest_paths_rdd.flatMap(_map_edges_count)
    edges_count_rdd.cache()

    edges_paths_count_rdd = edges_count_rdd.join(paths_count_rdd)

    # edges_betweenness_per_path_rdd -> [(edge, betweenness)]
    # this produces the edge betweennes per path,
    # i.e. one edge can appear several times in this rdd,
    # one time per each shortest path
    edges_betweenness_per_path_rdd = edges_paths_count_rdd.map(lambda row: (
        row[1][0][0],  # edge
        row[1][0][1] / row[1][1]  # edge_count / path_count  (sigma_st(e) / sigma_st in Girvan-Newman paper)
    ))

    # edge_betweenness_rdd -> [(edge, betweenness)]
    # aggregates (sums) the betweenness of the edges
    # In this rdd each edge appears only once.
    edge_betweenness_rdd = edges_betweenness_per_path_rdd.reduceByKey(
        lambda accumulator, edge_count: accumulator + edge_count
    )

    return edge_betweenness_rdd


def _map_paths_count(rdd_row):
    source, paths_dict = rdd_row

    paths_count = list()

    for (target, paths_list) in paths_dict.items():

        u, v = min(source, target), max(source, target)

        paths_count.append(
            ((u, v), len(paths_list))
        )

    return paths_count


def _get_edge_count(paths_list):
    """
    Get the number of shortest paths through each edge
    :param paths_list:
    :return: key = edge, value = count of shortest paths through that edge to this target
    """
    edge_count = dict()

    for path in paths_list:
        for i in range(len(path) - 1):
            u, v = min(path[i], path[i + 1]), max(path[i], path[i + 1])

            edge = (u, v)
            edge_count[edge] = edge_count.get(edge, 0) + 1.0

    return edge_count


def _map_edges_count(rdd_row):
    source, paths_dict = rdd_row

    edges_count_list = list()

    for (target, paths_list) in paths_dict.items():
        for (edge, edge_count) in _get_edge_count(paths_list).items():
            u, v = min(source, target), max(source, target)

            edges_count_list.append((
                (u, v), (edge, edge_count)
            ))

    return edges_count_list

